globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbd55ab9639e1e66.js",
    "static/chunks/ca78a3749976f35f.js",
    "static/chunks/ff07fd46409b0e0a.js",
    "static/chunks/96dbdc0078c3e232.js",
    "static/chunks/turbopack-2fa4107f1b23c333.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];